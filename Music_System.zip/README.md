# 音乐数据分析系统

这是一个基于Flask的音乐数据分析系统，用于分析和可视化音乐数据。

## 功能特点

- 用户认证系统（注册/登录）
- 市场分析：展示不同市场的音乐分布
- 年度趋势：展示歌曲发行数量的年度变化
- 歌手热度：分析歌手的热度排名

## 安装步骤

1. 克隆项目到本地
2. 创建虚拟环境（推荐）：
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate  # Windows
```

3. 安装依赖：
```bash
pip install -r requirements.txt
```

4. 运行应用：
```bash
python run.py
```

5. 访问网址：
打开浏览器访问 http://localhost:5000

## 数据来源

数据来自 Kuwo_music_data.xlsx 文件，包含了音乐市场、发行年份、歌手等信息。

## 技术栈

- 后端：Flask
- 数据库：SQLite
- 前端：Bootstrap 5
- 数据可视化：Chart.js
- 数据处理：Pandas 